ScrollSpeed - keyboard/mouse-only source

Changes in this package
-----------------------
- Removed all XInput types, imports/lookups, hooks, detours, polling, and controller-state processing.
- Removed the MinHook dependency and initialization; this source no longer calls MinHook.
- Kept the game's movement-vector hook, WASD tracking, modifier + mouse-wheel speed adjustment,
  weapon/combat state logic, title display, and logging.
- Kept the existing Windows keyboard/mouse hooks. WASD is still passed through to the game.

Build notes
-----------
This package contains source and configuration only. It does NOT contain a newly compiled ASI.
Build ScrollSpeed.cpp as a 64-bit Windows DLL/ASI using the same compiler settings as your
existing mod. MinHook is no longer required by this source. Keep the output filename
ScrollSpeed.asi and place it beside ScrollSpeed.ini in the game's mod/plugin location.

The original version.dll and prebuilt ScrollSpeed.asi are intentionally not included: the
former is unrelated to this source edit and the latter would be a stale binary that still
contains the old implementation. Do not replace version.dll as part of this test.

Diagnostic expectation
----------------------
The new ScrollSpeed.log reports vectorHook, vectorScale, WASD state, weapon state, and combat
state. It no longer reports XInput counters because this build has no XInput subsystem.

Important limitation
--------------------
This change removes every XInput interaction implemented by ScrollSpeed.cpp. It cannot
prevent some other installed mod, loader, driver, or the game itself from selecting controller
prompts. If prompts persist with this build, the cause is outside this source's XInput code or
is caused by another part of the remaining plugin/game interaction.
